#define NDS_VERSION "democase_ast-v5_3_0-branch_5d91adc"
char * get_version(void){return NDS_VERSION;}
